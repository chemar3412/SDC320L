﻿/********************************************8
Name: Chelsea Martin
Date: 5/17/2026
Assignment:SDC320 L Week 1 Inheritance and Composition

This is the main program for the bank account management application 

*/





using System;
using System.Collections.Generic;

public class Program
{
    static List<User> users = new List<User>();

    public static void Main()
    {
        Console.WriteLine("================================");
        Console.WriteLine(" Project Week 2 -- Bank System");
        Console.WriteLine("Created by: Chelsea Martin");

        Console.WriteLine("Welcome to the bank account management system");
        Console.WriteLine("Instructions: Select an option from the menu below");

        SeedData();

        bool running = true;
        while (running)
        {
            Console.WriteLine("\n Main Menu");
            Console.WriteLine("1. Display all users & accounts");
            Console.WriteLine("2. Display accounts for a user");
            Console.WriteLine("3. Open new user account");
            Console.WriteLine("4. Add an account");
            Console.WriteLine("5. Remove an account");
            Console.WriteLine("6. Deposit into an account");
            Console.WriteLine("7. Withdraw from an account");
            Console.WriteLine("8. Update user information");
            Console.WriteLine("9. Exit");

            string choice = Console.ReadLine() ?? string.Empty;

            switch (choice)
            {
                case "1": DisplayAllUsers(); break;
                case "2": DisplayUser(); break;
                case "3": OpenNewUserAccount(); break;
                case "4": AddAccount(); break;
                case "5": RemoveAccount(); break;
                case "6": Deposit(); break;
                case "7": Withdraw(); break;
                case "8": UpdateUserInfo(); break;
                case "9": running = false; break;
                default: Console.WriteLine("Invalid option."); break;
            }
        }
    }

    // -----------------------------
    // SUPPORTING METHODS
    // -----------------------------

    static void SeedData()
    {
        User u1 = new User("Alice Johnson", "alice@example.com");
        u1.AddAccount(new CheckingAccount("CHK1001", 500));
        u1.AddAccount(new SavingsAccount("SAV2001", 1500));

        User u2 = new User("Mark Thomas", "mark@example.com");
        u2.AddAccount(new BusinessAccount("BUS3001", 5000));
        u2.AddAccount(new CheckingAccount("CHK1002", 800));

        users.Add(u1);
        users.Add(u2);
    }

    static User? FindUser()
    {
        Console.Write("Enter user name: ");
        string name = Console.ReadLine() ?? string.Empty;
        return users.Find(u => u.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
    }

    static IAccount? FindAccount(User user)
    {
        Console.Write("Enter account number: ");
        string acct = Console.ReadLine() ?? string.Empty;
        return user.Accounts.Find(a => a.AccountNumber == acct);
    }

    static void DisplayAllUsers()
    {
        Console.WriteLine("\n All Users and Accounts");

        foreach (var user in users)
        {
            Console.WriteLine($"User: {user.Name} | Email: {user.Email}");
            user.DisplayUserAccounts();
        }
    }

    static void DisplayUser()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }
        user.DisplayUserAccounts();
    }

    static void OpenNewUserAccount()
    {
        Console.Write("Enter new user name: ");
        string name = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter email address: ");
        string email = Console.ReadLine() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email))
        {
            Console.WriteLine("Name and email are required.");
            return;
        }

        users.Add(new User(name.Trim(), email.Trim()));
        Console.WriteLine("New user account opened successfully.");
    }

    static void AddAccount()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        Console.WriteLine("Select account type:");
        Console.WriteLine("1. Checking");
        Console.WriteLine("2. Savings");
        Console.WriteLine("3. Business");

        string type = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter account number: ");
        string acctNum = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter initial balance: ");
        double balance = double.Parse(Console.ReadLine() ?? "0");

        BankAccount? acct = type switch
        {
            "1" => new CheckingAccount(acctNum, balance),
            "2" => new SavingsAccount(acctNum, balance),
            "3" => new BusinessAccount(acctNum, balance),
            _ => null
        };

        if (acct == null)
        {
            Console.WriteLine("Invalid account type.");
            return;
        }

        user.AddAccount(acct);
        Console.WriteLine("Account added successfully.");
    }

    static void RemoveAccount()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        Console.Write("Enter account number to remove: ");
        string acctNum = Console.ReadLine() ?? string.Empty;

        user.RemoveAccount(acctNum);
        Console.WriteLine("Account removed (if it existed).");
    }

    static void Deposit()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        IAccount? acct = FindAccount(user);
        if (acct == null)
        {
            Console.WriteLine("Account not found.");
            return;
        }

        Console.Write("Enter deposit amount: ");
        double amount = double.Parse(Console.ReadLine() ?? "0");

        acct.Deposit(amount);
        Console.WriteLine("Deposit successful.");
    }

    static void Withdraw()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        IAccount? acct = FindAccount(user);
        if (acct == null)
        {
            Console.WriteLine("Account not found.");
            return;
        }

        Console.Write("Enter withdrawal amount: ");
        double amount = double.Parse(Console.ReadLine() ?? "0");

        if (acct.Withdraw(amount))
            Console.WriteLine("Withdrawal successful.");
        else
            Console.WriteLine("Insufficient funds.");
    }

    static void UpdateUserInfo()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        Console.Write("Enter new name (leave blank to keep current): ");
        string newName = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter new email (leave blank to keep current): ");
        string newEmail = Console.ReadLine() ?? string.Empty;

        if (!string.IsNullOrWhiteSpace(newName))
            user.Name = newName;

        if (!string.IsNullOrWhiteSpace(newEmail))
            user.Email = newEmail;

        Console.WriteLine("User information updated.");
    }
}