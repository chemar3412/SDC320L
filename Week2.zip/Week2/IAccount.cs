/**************************
Name: Chelsea Martin
Date: 5/24/2026
Assignment: SDC320 L Week 1 Bank Account project Inheritance and Composition

This interface defines the common operations for bank accounts.
*/

public interface IAccount
{
    string AccountNumber { get; set; }
    double Balance { get; }

    void Deposit(double amount);
    bool Withdraw(double amount);
    void DisplayInfo();
}
