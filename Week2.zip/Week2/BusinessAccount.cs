/**************************
Name: Chelsea Martin
Date: 5/17/2026
Assignment: SDC320 L Week 1 Bank Account project Inheritance and Composition

This class is Business Account it i derived from the Bank account class. 

*/


using System;

public class BusinessAccount : BankAccount
{
    public BusinessAccount(string acctNum, double balance)
        : base(acctNum, balance) { }

public override void DisplayInfo()
{
    Console.WriteLine($"[Business] {AccountNumber} | Balance: {Balance}");
}
}