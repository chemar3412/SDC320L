/**************************
Name: Chelsea Martin
Date: 5/17/2026
Assignment: SDC320 L Week 1 Bank Account project Inheritance and Composition

This class is the for the bank account it is the base class for the program

*/

using System;

public abstract class BankAccount : IAccount
{
    public string AccountNumber { get; set; }
    public double Balance { get; protected set; }

    public BankAccount(string acctNum, double balance)
    {
        AccountNumber = acctNum;
        Balance = balance;
    }

    public virtual void Deposit(double amount)
    {
        Balance += amount;
    }

    public virtual bool Withdraw(double amount)
    {
        if (Balance >= amount)
        {
            Balance -= amount;
            return true;
        }
        return false;
    }

    public abstract void DisplayInfo();
}