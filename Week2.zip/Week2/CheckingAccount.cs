/**************************
Name: Chelsea Martin
Date: 5/17/2026
Assignment: SDC320 L Week 1 Bank Account project Inheritance and Composition

This class is checking account it is derived from the Bank Account CLass

*/


using System;

public class CheckingAccount : BankAccount
{
    public CheckingAccount(string acctNum, double balance)
        : base(acctNum, balance) { }

 public override void DisplayInfo()
{
    Console.WriteLine($"[Checking] {AccountNumber} | Balance: {Balance}");
}
}