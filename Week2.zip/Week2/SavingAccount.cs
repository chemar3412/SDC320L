/**************************
Name: Chelsea Martin
Date: 5/17/2026
Assignment: SDC320 L Week 1 Bank Account project Inheritance and Composition

This class is SavingsAccount it is derived from the Bank account Class

*/

using System;

public class SavingsAccount : BankAccount
{
    public SavingsAccount(string acctNum, double balance)
        : base(acctNum, balance) { }

 public override void DisplayInfo()
{
    Console.WriteLine($"[Savings] {AccountNumber} | Balance: {Balance}");
}
}