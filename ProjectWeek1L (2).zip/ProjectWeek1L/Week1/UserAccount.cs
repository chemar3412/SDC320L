/**************************
Name: Chelsea Martin
Date: 5/17/2026
Assignment: SDC320 L Week 1 Bank Account project Inheritance and Composition

Thsis is the User class it hold all the methods to add accounts remove accounts and update information 

*/


using System;
using System.Collections.Generic;

public class User
{
    public string Name { get; set; }
    public string Email { get; set; }
    public List<BankAccount> Accounts { get; set; } = new List<BankAccount>();

    public User(string name, string email)
    {
        Name = name;
        Email = email;
    }

    public void AddAccount(BankAccount acct)
    {
        Accounts.Add(acct);
    }

    public void RemoveAccount(string acctNum)
    {
        Accounts.RemoveAll(a => a.AccountNumber == acctNum);
    }

    public void DisplayUserAccounts()
    {
        Console.WriteLine($"Accounts for {Name}:");

        if (Accounts.Count == 0)
        {
            Console.WriteLine("  No accounts.");
            return;
        }

        foreach (var acct in Accounts)
        {
            acct.DisplayInfo();
        }
    }
}