/**************************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Week 3 – Abstraction, Constructors, Access Specifiers

Purpose:
This class represents a Savings Account and inherits from the
abstract BankAccount class. It demonstrates abstraction by
implementing DisplayInfo(), constructor overloading, and proper
use of access specifiers. It also includes savings-specific
behavior such as interest accumulation.
**************************************************/

using System;

public class SavingsAccount : BankAccount
{
    public double InterestRate { get; private set; }

    public SavingsAccount() : base()
    {
        InterestRate = 0.01;
    }

    public SavingsAccount(string acctNum, double balance, double interestRate)
        : base(acctNum, balance)
    {
        InterestRate = interestRate;
    }

    public SavingsAccount(SavingsAccount other)
        : base(other)
    {
        InterestRate = other.InterestRate;
    }

    public void ApplyInterest()
    {
        Balance += Balance * InterestRate;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Savings Account]");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Balance: {Balance:C}");
        Console.WriteLine($"Interest Rate: {InterestRate:P}");
        Console.WriteLine("-----------------------------------");
    }
}