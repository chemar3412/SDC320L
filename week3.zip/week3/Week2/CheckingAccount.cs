/**************************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Week 3 – Abstraction, Constructors, Access Specifiers

Purpose:
This class represents a Checking Account and inherits from the
abstract BankAccount class. It demonstrates abstraction by
implementing DisplayInfo(), constructor overloading, and proper
use of access specifiers.
**************************************************/

using System;

public class CheckingAccount : BankAccount
{
    public double OverdraftLimit { get; private set; }

    public CheckingAccount() : base()
    {
        OverdraftLimit = 0.0;
    }

    public CheckingAccount(string acctNum, double balance, double overdraftLimit)
        : base(acctNum, balance)
    {
        OverdraftLimit = overdraftLimit;
    }

    public CheckingAccount(CheckingAccount other)
        : base(other)
    {
        OverdraftLimit = other.OverdraftLimit;
    }

    public override bool Withdraw(double amount)
    {
        if (Balance + OverdraftLimit >= amount)
        {
            Balance -= amount;
            return true;
        }
        return false;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Checking Account]");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Balance: {Balance:C}");
        Console.WriteLine($"Overdraft Limit: {OverdraftLimit:C}");
        Console.WriteLine("-----------------------------------");
    }
}