/**************************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Week 3 – Abstraction, Constructors, Access Specifiers

Purpose:
This class represents a Business Account and inherits from the
abstract BankAccount class. It demonstrates abstraction by
implementing the required DisplayInfo() method and constructor
overloading through multiple constructors.
**************************************************/

using System;

public class BusinessAccount : BankAccount
{
    public string BusinessName { get; private set; }

    public BusinessAccount() : base()
    {
        BusinessName = "Unknown Business";
    }

    public BusinessAccount(string acctNum, double balance, string businessName)
        : base(acctNum, balance)
    {
        BusinessName = businessName;
    }

    public BusinessAccount(BusinessAccount other)
        : base(other)
    {
        BusinessName = other.BusinessName;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"[Business Account]");
        Console.WriteLine($"Business Name: {BusinessName}");
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Balance: {Balance:C}");
        Console.WriteLine("-----------------------------------");
    }
}