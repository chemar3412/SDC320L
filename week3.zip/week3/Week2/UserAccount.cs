/**************************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Week 3 – Abstraction, Constructors, Composition

Purpose:
This class represents a User/Customer in the banking system.
It demonstrates composition (a User has multiple accounts),
constructor overloading, and proper use of access specifiers.
**************************************************/

using System;
using System.Collections.Generic;

public class User
{
    public string Name { get; private set; }
    public string Email { get; private set; }

    private List<IAccount> Accounts { get; set; } = new List<IAccount>();

    public User()
    {
        Name = "Unknown User";
        Email = "unknown@example.com";
    }

    public User(string name, string email)
    {
        Name = name;
        Email = email;
    }

    public User(User other)
    {
        Name = other.Name;
        Email = other.Email;

        Accounts = new List<IAccount>();
        foreach (var acct in other.Accounts)
            Accounts.Add(acct);
    }

    public void AddAccount(IAccount acct)
    {
        Accounts.Add(acct);
    }

    public void RemoveAccount(string acctNum)
    {
        Accounts.RemoveAll(a => a.AccountNumber == acctNum);
    }

    public IReadOnlyList<IAccount> GetAccounts()
    {
        return Accounts.AsReadOnly();
    }

    public void UpdateName(string newName)
    {
        Name = newName;
    }

    public void UpdateEmail(string newEmail)
    {
        Email = newEmail;
    }

    public void DisplayUserAccounts()
    {
        Console.WriteLine("-----------------------------------");
        Console.WriteLine($"Accounts for {Name} ({Email})");
        Console.WriteLine("-----------------------------------");

        if (Accounts.Count == 0)
        {
            Console.WriteLine("No accounts found.");
            return;
        }

        foreach (var acct in Accounts)
            acct.DisplayInfo();
    }
}