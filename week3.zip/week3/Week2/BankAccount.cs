/**************************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Week 3 – Abstraction, Constructors, Access Specifiers

Purpose:
This abstract class represents the base structure for all bank
accounts. It demonstrates abstraction by requiring derived classes
to implement DisplayInfo(). It also demonstrates constructor
overloading and proper use of access specifiers.
**************************************************/

using System;

public abstract class BankAccount : IAccount
{
    private string _accountNumber;

    public string AccountNumber
    {
        get { return _accountNumber; }
        private set { _accountNumber = value; }
    }

    public double Balance { get; protected set; }

    public BankAccount()
    {
        AccountNumber = "000000";
        Balance = 0.0;
    }

    public BankAccount(string acctNum, double balance)
    {
        AccountNumber = acctNum;
        Balance = balance;
    }

    public BankAccount(BankAccount other)
    {
        AccountNumber = other.AccountNumber;
        Balance = other.Balance;
    }

    public virtual void Deposit(double amount)
    {
        Balance += amount;
    }

    public virtual bool Withdraw(double amount)
    {
        if (Balance >= amount)
        {
            Balance -= amount;
            return true;
        }
        return false;
    }

    public abstract void DisplayInfo();
}