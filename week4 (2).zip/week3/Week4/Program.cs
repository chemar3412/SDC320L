﻿/**************************************************
Name: Chelsea Martin
Date: 5/31/2026
Assignment: SDC320 Week 3 – Abstraction, Inheritance, Composition

Purpose:
This is the main program for the bank account management system.
It demonstrates abstraction (interfaces + abstract classes),
inheritance (Checking, Savings, Business accounts), composition
(Users have accounts), constructor overloading, and proper use of
access specifiers throughout the application.
**************************************************/

using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

public class Program
{
    private const string DatabaseFile = "bank.db";
    private static readonly string ConnectionString = $"Data Source={DatabaseFile};";
    static List<User> users = new List<User>();

    public static void Main()
    {
        Console.WriteLine("===============================================");
        Console.WriteLine("        Project Week 4 — Bank System");
        Console.WriteLine("        Created by: Chelsea Martin");
        Console.WriteLine("===============================================");
        Console.WriteLine("Welcome to the Bank Account Management System");
        Console.WriteLine("Instructions: Select an option from the menu below.");

        InitializeDatabase();
        if (!LoadUsersFromDatabase())
        {
            SeedData();
            SaveUsersToDatabase();
        }

        bool running = true;
        while (running)
        {
            Console.WriteLine("\nMain Menu");
            Console.WriteLine("1. Display all users & accounts");
            Console.WriteLine("2. Display accounts for a user");
            Console.WriteLine("3. Open new user account");
            Console.WriteLine("4. Add an account to a user");
            Console.WriteLine("5. Remove an account");
            Console.WriteLine("6. Deposit into an account");
            Console.WriteLine("7. Withdraw from an account");
            Console.WriteLine("8. Update user information");
            Console.WriteLine("9. View database contents");
            Console.WriteLine("10. Exit");

            Console.Write("Select an option: ");
            string choice = Console.ReadLine() ?? string.Empty;

            switch (choice)
            {
                case "1": DisplayAllUsers(); break;
                case "2": DisplayUser(); break;
                case "3": OpenNewUserAccount(); break;
                case "4": AddAccount(); break;
                case "5": RemoveAccount(); break;
                case "6": Deposit(); break;
                case "7": Withdraw(); break;
                case "8": UpdateUserInfo(); break;
                case "9": DisplayDatabaseContents(); break;
                case "10": running = false; break;
                default: Console.WriteLine("Invalid option."); break;
            }
        }
    }

    static void SeedData()
    {
        User u1 = new User("Alice Johnson", "alice@example.com");
        u1.AddAccount(new CheckingAccount("CHK1001", 500, 200));
        u1.AddAccount(new SavingsAccount("SAV2001", 1500, 0.03));

        User u2 = new User("Mark Thomas", "mark@example.com");
        u2.AddAccount(new BusinessAccount("BUS3001", 5000, "Mark's Auto Repair"));
        u2.AddAccount(new CheckingAccount("CHK1002", 800, 100));

        users.Add(u1);
        users.Add(u2);
    }

    static void InitializeDatabase()
    {
        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();

        using var command = connection.CreateCommand();
        command.CommandText = @"
CREATE TABLE IF NOT EXISTS Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Email TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Accounts (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    AccountNumber TEXT NOT NULL UNIQUE,
    Balance REAL NOT NULL,
    AccountType TEXT NOT NULL,
    OverdraftLimit REAL,
    InterestRate REAL,
    BusinessName TEXT,
    UserId INTEGER NOT NULL,
    FOREIGN KEY(UserId) REFERENCES Users(Id)
);
";
        command.ExecuteNonQuery();
    }

    static bool LoadUsersFromDatabase()
    {
        users.Clear();

        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();

        using var selectUsers = connection.CreateCommand();
        selectUsers.CommandText = "SELECT Id, Name, Email FROM Users";

        using var reader = selectUsers.ExecuteReader();
        bool loaded = false;

        while (reader.Read())
        {
            loaded = true;
            int userId = reader.GetInt32(0);
            string name = reader.GetString(1);
            string email = reader.GetString(2);

            var user = new User(name, email);
            users.Add(user);
            LoadAccountsForUser(connection, userId, user);
        }

        return loaded;
    }

    static void LoadAccountsForUser(SqliteConnection connection, int userId, User user)
    {
        using var selectAccounts = connection.CreateCommand();
        selectAccounts.CommandText = @"
SELECT AccountNumber, Balance, AccountType, OverdraftLimit, InterestRate, BusinessName
FROM Accounts
WHERE UserId = @userId";
        selectAccounts.Parameters.AddWithValue("@userId", userId);

        using var reader = selectAccounts.ExecuteReader();
        while (reader.Read())
        {
            string acctNum = reader.GetString(0);
            double balance = reader.GetDouble(1);
            string accountType = reader.GetString(2);
            double overdraftLimit = reader.IsDBNull(3) ? 0.0 : reader.GetDouble(3);
            double interestRate = reader.IsDBNull(4) ? 0.0 : reader.GetDouble(4);
            string businessName = reader.IsDBNull(5) ? string.Empty : reader.GetString(5);

            BankAccount account = accountType switch
            {
                "Checking" => new CheckingAccount(acctNum, balance, overdraftLimit),
                "Savings" => new SavingsAccount(acctNum, balance, interestRate),
                "Business" => new BusinessAccount(acctNum, balance, businessName),
                _ => new CheckingAccount(acctNum, balance, 0)
            };

            user.AddAccount(account);
        }
    }

    static void SaveUsersToDatabase()
    {
        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();

        using var transaction = connection.BeginTransaction();

        using var clearAccounts = connection.CreateCommand();
        clearAccounts.CommandText = "DELETE FROM Accounts";
        clearAccounts.ExecuteNonQuery();

        using var clearUsers = connection.CreateCommand();
        clearUsers.CommandText = "DELETE FROM Users";
        clearUsers.ExecuteNonQuery();

        foreach (var user in users)
        {
            using var insertUser = connection.CreateCommand();
            insertUser.CommandText = "INSERT INTO Users (Name, Email) VALUES (@name, @email)";
            insertUser.Parameters.AddWithValue("@name", user.Name);
            insertUser.Parameters.AddWithValue("@email", user.Email);
            insertUser.ExecuteNonQuery();

            using var lastIdCmd = connection.CreateCommand();
            lastIdCmd.CommandText = "SELECT last_insert_rowid();";
            long userId = (long)lastIdCmd.ExecuteScalar();

            foreach (var account in user.GetAccounts())
            {
                using var insertAccount = connection.CreateCommand();
                insertAccount.CommandText = @"
INSERT INTO Accounts
    (AccountNumber, Balance, AccountType, OverdraftLimit, InterestRate, BusinessName, UserId)
VALUES
    (@acctNum, @balance, @type, @overdraft, @interest, @business, @userId)";

                insertAccount.Parameters.AddWithValue("@acctNum", account.AccountNumber);
                insertAccount.Parameters.AddWithValue("@balance", account.Balance);

                if (account is CheckingAccount checking)
                {
                    insertAccount.Parameters.AddWithValue("@type", "Checking");
                    insertAccount.Parameters.AddWithValue("@overdraft", checking.OverdraftLimit);
                    insertAccount.Parameters.AddWithValue("@interest", DBNull.Value);
                    insertAccount.Parameters.AddWithValue("@business", DBNull.Value);
                }
                else if (account is SavingsAccount savings)
                {
                    insertAccount.Parameters.AddWithValue("@type", "Savings");
                    insertAccount.Parameters.AddWithValue("@overdraft", DBNull.Value);
                    insertAccount.Parameters.AddWithValue("@interest", savings.InterestRate);
                    insertAccount.Parameters.AddWithValue("@business", DBNull.Value);
                }
                else if (account is BusinessAccount business)
                {
                    insertAccount.Parameters.AddWithValue("@type", "Business");
                    insertAccount.Parameters.AddWithValue("@overdraft", DBNull.Value);
                    insertAccount.Parameters.AddWithValue("@interest", DBNull.Value);
                    insertAccount.Parameters.AddWithValue("@business", business.BusinessName);
                }
                else
                {
                    insertAccount.Parameters.AddWithValue("@type", "Unknown");
                    insertAccount.Parameters.AddWithValue("@overdraft", DBNull.Value);
                    insertAccount.Parameters.AddWithValue("@interest", DBNull.Value);
                    insertAccount.Parameters.AddWithValue("@business", DBNull.Value);
                }

                insertAccount.Parameters.AddWithValue("@userId", userId);
                insertAccount.ExecuteNonQuery();
            }
        }

        transaction.Commit();
    }

    static User? FindUser()
    {
        Console.Write("Enter user name: ");
        string name = Console.ReadLine() ?? string.Empty;

        return users.Find(u => u.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
    }

    static IAccount? FindAccount(User user)
    {
        Console.Write("Enter account number: ");
        string acct = Console.ReadLine() ?? string.Empty;

        foreach (var a in user.GetAccounts())
        {
            if (a.AccountNumber == acct)
                return a;
        }

        return null;
    }

    static void DisplayAllUsers()
    {
        Console.WriteLine("\nAll Users and Accounts");

        foreach (var user in users)
            user.DisplayUserAccounts();
    }

    static void DisplayUser()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        user.DisplayUserAccounts();
    }

    static void DisplayDatabaseContents()
    {
        Console.WriteLine("\nBank.db Contents:");

        using var connection = new SqliteConnection(ConnectionString);
        connection.Open();

        using var command = connection.CreateCommand();
        command.CommandText = @"
SELECT u.Name, u.Email, a.AccountNumber, a.Balance, a.AccountType,
       a.OverdraftLimit, a.InterestRate, a.BusinessName
FROM Users u
LEFT JOIN Accounts a ON u.Id = a.UserId
ORDER BY u.Id, a.Id";

        using var reader = command.ExecuteReader();
        if (!reader.HasRows)
        {
            Console.WriteLine("No data found in the database.");
            return;
        }

        string lastUser = string.Empty;
        while (reader.Read())
        {
            string name = reader.GetString(0);
            string email = reader.GetString(1);
            string accountNumber = reader.IsDBNull(2) ? string.Empty : reader.GetString(2);
            double balance = reader.IsDBNull(3) ? 0.0 : reader.GetDouble(3);
            string accountType = reader.IsDBNull(4) ? string.Empty : reader.GetString(4);
            string overdraft = reader.IsDBNull(5) ? string.Empty : reader.GetDouble(5).ToString("C");
            string interest = reader.IsDBNull(6) ? string.Empty : reader.GetDouble(6).ToString("P");
            string businessName = reader.IsDBNull(7) ? string.Empty : reader.GetString(7);

            if (name != lastUser)
            {
                Console.WriteLine($"\nUser: {name} ({email})");
                lastUser = name;
            }

            if (string.IsNullOrEmpty(accountNumber))
            {
                Console.WriteLine("  No accounts for this user.");
                continue;
            }

            Console.WriteLine($"  - {accountType} Account: {accountNumber} | Balance: {balance:C}");
            if (accountType == "Checking")
                Console.WriteLine($"      Overdraft Limit: {overdraft}");
            if (accountType == "Savings")
                Console.WriteLine($"      Interest Rate: {interest}");
            if (accountType == "Business")
                Console.WriteLine($"      Business Name: {businessName}");
        }
    }

    static void OpenNewUserAccount()
    {
        Console.Write("Enter new user name: ");
        string name = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter email address: ");
        string email = Console.ReadLine() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email))
        {
            Console.WriteLine("Name and email are required.");
            return;
        }

        users.Add(new User(name.Trim(), email.Trim()));
        SaveUsersToDatabase();
        Console.WriteLine("New user account created successfully.");
    }

    static void AddAccount()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        Console.WriteLine("Select account type:");
        Console.WriteLine("1. Checking");
        Console.WriteLine("2. Savings");
        Console.WriteLine("3. Business");

        string type = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter account number: ");
        string acctNum = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter initial balance: ");
        double balance = double.Parse(Console.ReadLine() ?? "0");

        BankAccount? acct = type switch
        {
            "1" => new CheckingAccount(acctNum, balance, 200),
            "2" => new SavingsAccount(acctNum, balance, 0.02),
            "3" => new BusinessAccount(acctNum, balance, "New Business"),
            _ => null
        };

        if (acct == null)
        {
            Console.WriteLine("Invalid account type.");
            return;
        }

        user.AddAccount(acct);
        SaveUsersToDatabase();
        Console.WriteLine("Account added successfully.");
    }

    static void RemoveAccount()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        Console.Write("Enter account number to remove: ");
        string acctNum = Console.ReadLine() ?? string.Empty;

        user.RemoveAccount(acctNum);
        SaveUsersToDatabase();
        Console.WriteLine("Account removed (if it existed).");
    }

    static void Deposit()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        IAccount? acct = FindAccount(user);
        if (acct == null)
        {
            Console.WriteLine("Account not found.");
            return;
        }

        Console.Write("Enter deposit amount: ");
        double amount = double.Parse(Console.ReadLine() ?? "0");

        acct.Deposit(amount);
        SaveUsersToDatabase();
        Console.WriteLine("Deposit successful.");
    }

    static void Withdraw()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        IAccount? acct = FindAccount(user);
        if (acct == null)
        {
            Console.WriteLine("Account not found.");
            return;
        }

        Console.Write("Enter withdrawal amount: ");
        double amount = double.Parse(Console.ReadLine() ?? "0");

        if (acct.Withdraw(amount))
        {
            SaveUsersToDatabase();
            Console.WriteLine("Withdrawal successful.");
        }
        else
        {
            Console.WriteLine("Insufficient funds.");
        }
    }

    static void UpdateUserInfo()
    {
        User? user = FindUser();
        if (user == null)
        {
            Console.WriteLine("User not found.");
            return;
        }

        Console.Write("Enter new name (leave blank to keep current): ");
        string newName = Console.ReadLine() ?? string.Empty;

        Console.Write("Enter new email (leave blank to keep current): ");
        string newEmail = Console.ReadLine() ?? string.Empty;

        if (!string.IsNullOrWhiteSpace(newName))
            user.UpdateName(newName);

        if (!string.IsNullOrWhiteSpace(newEmail))
            user.UpdateEmail(newEmail);

        SaveUsersToDatabase();
        Console.WriteLine("User information updated.");
    }
}